import 'package:flutter_test/flutter_test.dart';
import 'package:ludo_king_remastered/main.dart';

void main() {
  testWidgets('App smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const LudoApp());
    expect(find.text('LUDO KING'), findsOneWidget);
  });
}
