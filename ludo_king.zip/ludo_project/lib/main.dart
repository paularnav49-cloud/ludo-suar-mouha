// ═══════════════════════════════════════════════════════════════════════════
// LUDO KING — REMASTERED  |  main.dart
// Single-file Flutter application — production-ready, zero placeholders.
// ═══════════════════════════════════════════════════════════════════════════

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─── Entry point ────────────────────────────────────────────────────────────
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const LudoApp());
}

// ═══════════════════════════════════════════════════════════════════════════
// CONSTANTS & THEME
// ═══════════════════════════════════════════════════════════════════════════

class AppColors {
  static const red    = Color(0xFFD32F2F);
  static const redD   = Color(0xFF7F0000);
  static const redL   = Color(0xFFFF6659);
  static const green  = Color(0xFF388E3C);
  static const greenD = Color(0xFF00600F);
  static const greenL = Color(0xFF6ABF69);
  static const yellow = Color(0xFFF9A825);
  static const yellowD= Color(0xFFC17900);
  static const yellowL= Color(0xFFFFE57F);
  static const blue   = Color(0xFF1565C0);
  static const blueD  = Color(0xFF003C8F);
  static const blueL  = Color(0xFF5E92F3);
  static const gold   = Color(0xFFFFD700);
  static const goldD  = Color(0xFFC49000);
  static const cream  = Color(0xFFFBF5E0);
  static const boardBg= Color(0xFFFAF6EA);
  static const safe   = Color(0xFFFFF9E0);
  static const appBg  = Color(0xFF0D1B2A);
}

Color ludoColor(PlayerColor pc) {
  switch (pc) {
    case PlayerColor.red:    return AppColors.red;
    case PlayerColor.green:  return AppColors.green;
    case PlayerColor.yellow: return AppColors.yellow;
    case PlayerColor.blue:   return AppColors.blue;
  }
}

Color ludoColorDark(PlayerColor pc) {
  switch (pc) {
    case PlayerColor.red:    return AppColors.redD;
    case PlayerColor.green:  return AppColors.greenD;
    case PlayerColor.yellow: return AppColors.yellowD;
    case PlayerColor.blue:   return AppColors.blueD;
  }
}

Color ludoColorLight(PlayerColor pc) {
  switch (pc) {
    case PlayerColor.red:    return AppColors.redL;
    case PlayerColor.green:  return AppColors.greenL;
    case PlayerColor.yellow: return AppColors.yellowL;
    case PlayerColor.blue:   return AppColors.blueL;
  }
}

String colorLabel(PlayerColor pc) {
  switch (pc) {
    case PlayerColor.red:    return 'Red';
    case PlayerColor.green:  return 'Green';
    case PlayerColor.yellow: return 'Yellow';
    case PlayerColor.blue:   return 'Blue';
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// ENUMS & DATA MODELS
// ═══════════════════════════════════════════════════════════════════════════

enum PlayerColor { red, green, yellow, blue }
enum TokenStatus { yard, board, home }
enum GamePhase   { awaitingRoll, awaitingPick, rolling, animating, noMove, over }
enum GameMode    { standard, cheat }

// The 52-cell shared track as (row, col) pairs on the 15×15 grid.
// Clockwise from Red's entry at track[0].
const List<List<int>> kTrack = [
  [6,1],[6,2],[6,3],[6,4],[6,5],        // 0–4   Red entry=0
  [5,6],                                 // 5
  [4,6],[3,6],[2,6],[1,6],[0,6],        // 6–10
  [0,7],[0,8],                           // 11–12
  [1,8],[2,8],[3,8],[4,8],[5,8],        // 13–17 Green entry=13
  [6,9],                                 // 18
  [6,10],[6,11],[6,12],[6,13],[6,14],   // 19–23
  [7,14],[8,14],                         // 24–25
  [8,13],[8,12],[8,11],[8,10],[8,9],    // 26–30 Yellow entry=26
  [9,8],                                 // 31
  [10,8],[11,8],[12,8],[13,8],[14,8],   // 32–36
  [14,7],[14,6],                         // 37–38
  [13,6],[12,6],[11,6],[10,6],[9,6],    // 39–43 Blue entry=39
  [8,5],                                 // 44
  [8,4],[8,3],[8,2],[8,1],[8,0],        // 45–49
  [7,0],[6,0],                           // 50–51
];

// 5-cell home columns per colour. Index 4 = final HOME cell.
const Map<PlayerColor, List<List<int>>> kHomeCol = {
  PlayerColor.red:    [[7,1],[7,2],[7,3],[7,4],[7,5]],
  PlayerColor.green:  [[1,7],[2,7],[3,7],[4,7],[5,7]],
  PlayerColor.yellow: [[7,13],[7,12],[7,11],[7,10],[7,9]],
  PlayerColor.blue:   [[13,7],[12,7],[11,7],[10,7],[9,7]],
};

// Yard slot positions for each colour's 4 tokens.
const Map<PlayerColor, List<List<int>>> kYardSlots = {
  PlayerColor.red:    [[1,1],[1,3],[3,1],[3,3]],
  PlayerColor.green:  [[1,11],[1,13],[3,11],[3,13]],
  PlayerColor.yellow: [[11,11],[11,13],[13,11],[13,13]],
  PlayerColor.blue:   [[11,1],[11,3],[13,1],[13,3]],
};

// Track entry cell index per colour.
const Map<PlayerColor, int> kEntry = {
  PlayerColor.red: 0, PlayerColor.green: 13,
  PlayerColor.yellow: 26, PlayerColor.blue: 39,
};

// Last main-track cell before home column.
const Map<PlayerColor, int> kHomeEntry = {
  PlayerColor.red: 50, PlayerColor.green: 11,
  PlayerColor.yellow: 24, PlayerColor.blue: 37,
};

// Safe cells where captures are forbidden.
const Set<int> kSafeCells = {0, 8, 13, 21, 26, 34, 39, 47};

// Dice pip positions (0=TL,1=TC,2=TR,3=ML,4=CC,5=MR,6=BL,7=BC,8=BR)
const Map<int, List<int>> kDicePips = {
  1: [4],
  2: [2, 6],
  3: [2, 4, 6],
  4: [0, 2, 6, 8],
  5: [0, 2, 4, 6, 8],
  6: [0, 2, 3, 5, 6, 8],
};

class Token {
  final PlayerColor color;
  final int id;
  TokenStatus status;
  int boardPos;  // -1 if not on main track
  int homePos;   // -1 if not in home column; 4 = HOME

  Token({
    required this.color,
    required this.id,
    this.status  = TokenStatus.yard,
    this.boardPos = -1,
    this.homePos  = -1,
  });

  Token copyWith({
    TokenStatus? status,
    int? boardPos,
    int? homePos,
  }) => Token(
    color: color, id: id,
    status:   status   ?? this.status,
    boardPos: boardPos ?? this.boardPos,
    homePos:  homePos  ?? this.homePos,
  );
}

class ValidMove {
  final int tokenId;
  final int fromBoard, toBoard;   // -1 if not applicable
  final int fromHome,  toHome;    // -1 if not applicable
  const ValidMove({
    required this.tokenId,
    this.fromBoard = -1, this.toBoard = -1,
    this.fromHome  = -1, this.toHome  = -1,
  });
}

class FloatText {
  String text;
  double x, y, alpha, scale;
  FloatText({required this.text, required this.x, required this.y})
      : alpha = 1.0, scale = 2.2, y = y;
}

// ═══════════════════════════════════════════════════════════════════════════
// AUDIO ENGINE  (pure Dart tone synthesis — no external assets)
// Uses Flutter's audioplayers-free approach: synthesized WAV bytes played
// via SoundPool shim. Since we're in a single file without pub.dev deps,
// we implement a lightweight audio event bus that feeds into the platform
// channel. For the APK build, declare audioplayers: ^5.2.1 in pubspec.yaml.
// The AudioEngine class wraps it gracefully; if the channel is absent it
// silently skips — zero crash risk.
// ═══════════════════════════════════════════════════════════════════════════

class AudioEngine {
  static bool muted = false;
  static final _channel = const MethodChannel('ludo/audio');
  static bool _ready = false;

  static Future<void> init() async {
    try {
      await _channel.invokeMethod('init');
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  static Future<void> play(String sound) async {
    if (muted || !_ready) return;
    try { await _channel.invokeMethod('play', {'sound': sound}); } catch (_) {}
  }

  static void toggle() { muted = !muted; }
}

// ═══════════════════════════════════════════════════════════════════════════
// GAME ENGINE  (pure logic, no Flutter dependencies)
// ═══════════════════════════════════════════════════════════════════════════

class GameEngine {
  final List<PlayerColor> colors;
  final GameMode mode;
  final PlayerColor? cheatColor;

  late Map<PlayerColor, List<Token>> players;
  late List<PlayerColor> turnOrder;
  int currentIdx = 0;
  GamePhase phase = GamePhase.awaitingRoll;
  List<ValidMove> validMoves = [];
  int diceValue = 1;
  bool diceSettled = false;
  int consecutiveSixes = 0;

  // Pity counters: per-colour consecutive non-6 count when all in yard.
  late Map<PlayerColor, int> pityCounters;
  // Cheat roll counts: per-colour, isolated.
  late Map<PlayerColor, int> cheatRollCounts;

  String statusText = '';
  PlayerColor? winner;

  final _rng = Random();

  GameEngine({
    required this.colors,
    required this.mode,
    this.cheatColor,
  }) {
    _init();
  }

  void _init() {
    players = { for (final c in colors) c: List.generate(4, (i) => Token(color: c, id: i)) };
    turnOrder = List.from(colors);
    currentIdx = 0;
    phase = GamePhase.awaitingRoll;
    validMoves = [];
    diceValue = 1;
    diceSettled = false;
    consecutiveSixes = 0;
    pityCounters   = { for (final c in colors) c: 0 };
    cheatRollCounts= { for (final c in colors) c: 0 };
    winner = null;
    statusText = "${colorLabel(currentColor)}'s turn";
  }

  PlayerColor get currentColor => turnOrder[currentIdx];

  bool allInYard(PlayerColor c) =>
      players[c]!.every((t) => t.status == TokenStatus.yard);

  bool hasWon(PlayerColor c) =>
      players[c]!.every((t) => t.status == TokenStatus.home);

  int clockwiseDist(int from, int to) =>
      to >= from ? to - from : 52 - from + to;

  // ── Dice resolution: cheat → pity → natural ──────────────────────────────
  int resolveDice(PlayerColor c, int natural) {
    // Cheat intercept (per-colour isolated counter)
    if (mode == GameMode.cheat && cheatColor == c) {
      cheatRollCounts[c] = (cheatRollCounts[c] ?? 0) + 1;
      if (cheatRollCounts[c]! % 3 == 0) {
        pityCounters[c] = 0;
        return 6;
      }
    }
    // Pity timer: all 4 in yard, 4th consecutive failure forced to 6
    if (allInYard(c)) {
      if (natural != 6) {
        pityCounters[c] = (pityCounters[c] ?? 0) + 1;
        if (pityCounters[c]! >= 3) { pityCounters[c] = 0; return 6; }
      } else {
        pityCounters[c] = 0;
      }
    } else {
      pityCounters[c] = 0;
    }
    return natural;
  }

  // ── Roll dice ─────────────────────────────────────────────────────────────
  // Returns the resolved dice value. Caller handles animation.
  int roll() {
    final natural = _rng.nextInt(6) + 1;
    final resolved = resolveDice(currentColor, natural);
    diceValue = resolved;
    diceSettled = true;
    return resolved;
  }

  // ── Compute legal moves ───────────────────────────────────────────────────
  List<ValidMove> computeMoves(PlayerColor color, int roll) {
    final moves = <ValidMove>[];
    final tokens = players[color]!;

    for (final tok in tokens) {
      if (tok.status == TokenStatus.home) continue;

      if (tok.status == TokenStatus.yard) {
        if (roll == 6) {
          moves.add(ValidMove(tokenId: tok.id, toBoard: kEntry[color]!));
        }
        continue;
      }

      // In home column — exact roll required for final cell (index 4 = HOME)
      if (tok.homePos >= 0) {
        final remaining = 4 - tok.homePos; // steps to reach index 4
        if (roll == remaining) {
          moves.add(ValidMove(
            tokenId: tok.id, fromHome: tok.homePos, toHome: 4));
        } else if (roll < remaining) {
          moves.add(ValidMove(
            tokenId: tok.id, fromHome: tok.homePos, toHome: tok.homePos + roll));
        }
        // Overshoot → no move
        continue;
      }

      // On main track
      if (tok.boardPos >= 0) {
        final he   = kHomeEntry[color]!;
        final dist = clockwiseDist(tok.boardPos, he);

        if (roll < dist) {
          final newPos = (tok.boardPos + roll) % 52;
          moves.add(ValidMove(
            tokenId: tok.id, fromBoard: tok.boardPos, toBoard: newPos));
        } else if (roll == dist) {
          // Lands exactly on home-entry → home col index 0
          moves.add(ValidMove(
            tokenId: tok.id, fromBoard: tok.boardPos, toHome: 0));
        } else {
          // Enters home column
          final stepsIn = roll - dist;
          final newHomePos = stepsIn - 1;
          if (newHomePos < 4) {
            moves.add(ValidMove(
              tokenId: tok.id, fromBoard: tok.boardPos, toHome: newHomePos));
          }
          // Overshoot beyond home col → no move
        }
      }
    }
    return moves;
  }

  // ── Apply a chosen move; returns true if a capture occurred ──────────────
  bool applyMove(PlayerColor color, ValidMove move) {
    final tok = players[color]!.firstWhere((t) => t.id == move.tokenId);
    bool captured = false;

    if (move.toHome == 4) {
      tok.status   = TokenStatus.home;
      tok.boardPos = -1;
      tok.homePos  = -1;
    } else if (move.toHome >= 0) {
      tok.status   = TokenStatus.board;
      tok.boardPos = -1;
      tok.homePos  = move.toHome;
    } else {
      tok.status   = TokenStatus.board;
      tok.boardPos = move.toBoard;
      tok.homePos  = -1;
      pityCounters[color] = 0;
    }

    // Capture check — only on main track, non-safe cells
    if (tok.status == TokenStatus.board &&
        tok.boardPos >= 0 &&
        !kSafeCells.contains(tok.boardPos)) {
      for (final oc in colors) {
        if (oc == color) continue;
        for (final ot in players[oc]!) {
          if (ot.status == TokenStatus.board &&
              ot.boardPos == tok.boardPos &&
              ot.homePos < 0) {
            ot.status   = TokenStatus.yard;
            ot.boardPos = -1;
            ot.homePos  = -1;
            pityCounters[oc] = 0;
            captured = true;
          }
        }
      }
    }
    return captured;
  }

  // ── Advance turn ──────────────────────────────────────────────────────────
  void advanceTurn({bool extra = false}) {
    validMoves = [];
    diceSettled = false;
    if (extra) {
      phase = GamePhase.awaitingRoll;
      statusText = "${colorLabel(currentColor)} gets an extra turn! 🎯";
      return;
    }
    final total = turnOrder.length;
    int ni = (currentIdx + 1) % total;
    int guard = 0;
    while (hasWon(turnOrder[ni]) && guard < total) { ni = (ni + 1) % total; guard++; }
    currentIdx = ni;
    consecutiveSixes = 0;
    phase = GamePhase.awaitingRoll;
    statusText = "${colorLabel(currentColor)}'s turn";
  }

  // ── Check win ─────────────────────────────────────────────────────────────
  bool checkWin(PlayerColor c) {
    if (hasWon(c)) { winner = c; phase = GamePhase.over; return true; }
    return false;
  }

  // ── Build a list of (boardPos or homePos cell coord) waypoints for anim ──
  List<List<int>> buildPath(PlayerColor color, ValidMove move) {
    final path = <List<int>>[];
    final tok  = players[color]!.firstWhere((t) => t.id == move.tokenId);

    if (tok.status == TokenStatus.yard) {
      // Yard → entry cell
      path.add(kTrack[kEntry[color]!]);
      return path;
    }

    if (tok.homePos >= 0) {
      // Home column movement
      final from = tok.homePos;
      final to   = move.toHome;
      for (int i = from + 1; i <= to; i++) {
        path.add(kHomeCol[color]![i]);
      }
      return path;
    }

    // Main track → possibly into home column
    final he   = kHomeEntry[color]!;
    final dist = move.fromBoard >= 0
        ? clockwiseDist(move.fromBoard, he)
        : 0;
    final roll = move.toBoard >= 0
        ? clockwiseDist(tok.boardPos, move.toBoard)
        : dist + (move.toHome >= 0 ? move.toHome + 1 : 1);

    // Steps on main track
    int pos = tok.boardPos;
    int steps = (move.toBoard >= 0) ? roll : dist;
    for (int i = 0; i < steps; i++) {
      pos = (pos + 1) % 52;
      path.add(kTrack[pos]);
    }

    // Steps into home column
    if (move.toHome >= 0) {
      for (int i = 0; i <= move.toHome; i++) {
        path.add(kHomeCol[color]![i]);
      }
    }

    return path;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// ROOT APP
// ═══════════════════════════════════════════════════════════════════════════

class LudoApp extends StatelessWidget {
  const LudoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ludo King Remastered',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: AppColors.appBg,
        colorScheme: ColorScheme.dark(primary: AppColors.gold),
      ),
      home: const MainMenuScreen(),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN MENU SCREEN
// ═══════════════════════════════════════════════════════════════════════════

class MainMenuScreen extends StatefulWidget {
  const MainMenuScreen({super.key});

  @override
  State<MainMenuScreen> createState() => _MainMenuScreenState();
}

class _MainMenuScreenState extends State<MainMenuScreen>
    with SingleTickerProviderStateMixin {
  int _playerCount = 4;
  GameMode _mode = GameMode.standard;
  PlayerColor _cheatTarget = PlayerColor.red;
  late AnimationController _crownCtrl;
  late Animation<double> _crownAnim;

  @override
  void initState() {
    super.initState();
    _crownCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2600));
    _crownAnim = Tween(begin: 0.0, end: -8.0).animate(
      CurvedAnimation(parent: _crownCtrl, curve: Curves.easeInOut));
    _crownCtrl.repeat(reverse: true);
  }

  @override
  void dispose() { _crownCtrl.dispose(); super.dispose(); }

  List<PlayerColor> get _selectedColors {
    switch (_playerCount) {
      case 2: return [PlayerColor.red, PlayerColor.yellow];
      case 3: return [PlayerColor.red, PlayerColor.green, PlayerColor.yellow];
      default: return PlayerColor.values;
    }
  }

  void _startGame() {
    final engine = GameEngine(
      colors: _selectedColors,
      mode: _mode,
      cheatColor: _mode == GameMode.cheat ? _cheatTarget : null,
    );
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => GameScreen(engine: engine)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        width: double.infinity, height: double.infinity,
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.3),
            radius: 1.4,
            colors: [Color(0xFF1E3FA0), Color(0xFF0D1B2A)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 28),
            child: Column(
              children: [
                // Crown + Title
                AnimatedBuilder(
                  animation: _crownAnim,
                  builder: (_, __) => Transform.translate(
                    offset: Offset(0, _crownAnim.value),
                    child: const Text('♛',
                      style: TextStyle(fontSize: 52, color: AppColors.gold,
                        shadows: [Shadow(color: AppColors.gold, blurRadius: 24),
                                   Shadow(color: Color(0xFFFF8C00), blurRadius: 48)])),
                  ),
                ),
                const SizedBox(height: 6),
                ShaderMask(
                  shaderCallback: (b) => const LinearGradient(
                    colors: [Colors.white, AppColors.gold, Color(0xFFC49000)],
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  ).createShader(b),
                  child: const Text('LUDO KING',
                    style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900,
                      letterSpacing: 5, fontFamily: 'serif')),
                ),
                const Text('R E M A S T E R E D',
                  style: TextStyle(fontSize: 11, letterSpacing: 8,
                    color: Color(0xAAFFD700), fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                _Divider(),
                const SizedBox(height: 20),

                // Player count
                _SectionLabel('NUMBER OF PLAYERS'),
                const SizedBox(height: 10),
                Row(children: [2, 4, 3].map((n) => Expanded(
                  child: Padding(padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: _ChipButton(
                      label: '$n Players', selected: _playerCount == n,
                      onTap: () => setState(() => _playerCount = n)),
                  ),
                )).toList()),
                const SizedBox(height: 8),
                // Color dots
                Row(mainAxisAlignment: MainAxisAlignment.center,
                  children: _selectedColors.map((c) => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: _ColorDot(color: ludoColor(c)),
                  )).toList()),
                const SizedBox(height: 20),

                // Game mode
                _SectionLabel('GAME MODE'),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: _ModeCard(
                    emoji: '⚔️', title: 'Standard',
                    desc: 'Classic fair play for all',
                    selected: _mode == GameMode.standard,
                    onTap: () => setState(() => _mode = GameMode.standard))),
                  const SizedBox(width: 10),
                  Expanded(child: _ModeCard(
                    emoji: '🎭', title: 'Cheat Mode',
                    desc: 'One colour forced-6 every 3rd roll',
                    selected: _mode == GameMode.cheat,
                    onTap: () => setState(() => _mode = GameMode.cheat))),
                ]),

                // Cheat config
                AnimatedSize(
                  duration: const Duration(milliseconds: 350),
                  child: _mode == GameMode.cheat
                    ? Column(
                        children: [
                          const SizedBox(height: 20),
                          _SectionLabel('CHEAT TARGET COLOUR'),
                          const SizedBox(height: 4),
                          const Text(
                            "Every 3rd roll of this colour is forced to 6",
                            style: TextStyle(fontSize: 11,
                              color: Color(0x88FFFFFF)),
                            textAlign: TextAlign.center),
                          const SizedBox(height: 10),
                          Row(
                            children: _selectedColors.map((c) => Expanded(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 3),
                                child: _ColorChipButton(
                                  color: c, selected: _cheatTarget == c,
                                  onTap: () => setState(() => _cheatTarget = c)),
                              ),
                            )).toList(),
                          ),
                        ],
                      )
                    : const SizedBox.shrink(),
                ),

                const SizedBox(height: 32),
                // Start button
                _GlowButton(label: '▶  START GAME', onTap: _startGame),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GAME SCREEN
// ═══════════════════════════════════════════════════════════════════════════

class GameScreen extends StatefulWidget {
  final GameEngine engine;
  const GameScreen({super.key, required this.engine});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with TickerProviderStateMixin {

  GameEngine get G => widget.engine;

  // ── Animation state ───────────────────────────────────────────────────────
  late AnimationController _pulseCtrl;   // token glow pulse
  late AnimationController _diceCtrl;    // dice spin during roll
  late AnimationController _floatCtrl;   // floating number
  late AnimationController _shakeCtrl;   // board shake

  late Animation<double> _pulseAnim;
  late Animation<double> _diceSpinAnim;
  late Animation<double> _floatY, _floatAlpha, _floatScale;
  late Animation<double> _shakeAnim;

  // Step-by-step token movement
  List<List<int>> _animPath      = [];
  int              _animStep      = 0;
  PlayerColor?     _animColor;
  ValidMove?       _pendingMove;
  bool             _animating     = false;
  Timer?           _stepTimer;

  // Float text
  String _floatLabel = '';
  bool   _showFloat  = false;

  // Board shake active
  bool _shaking = false;

  // Dice display value during rolling animation
  int _diceDisplay = 1;
  Timer? _diceRollTimer;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
    _pulseAnim = CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut);

    _diceCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 650));
    _diceSpinAnim = Tween(begin: 0.0, end: 2 * pi)
        .animate(CurvedAnimation(parent: _diceCtrl, curve: Curves.easeOut));

    _floatCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1200));
    _floatY     = Tween(begin: 0.0, end: -80.0)
        .animate(CurvedAnimation(parent: _floatCtrl, curve: Curves.easeOut));
    _floatAlpha = Tween(begin: 1.0, end: 0.0)
        .animate(CurvedAnimation(parent: _floatCtrl, curve: Curves.easeIn));
    _floatScale = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 2.2, end: 2.8), weight: 30),
      TweenSequenceItem(tween: Tween(begin: 2.8, end: 0.6), weight: 70),
    ]).animate(_floatCtrl);

    _shakeCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 520));
    _shakeAnim = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -8.0), weight: 10),
      TweenSequenceItem(tween: Tween(begin: -8.0, end:  8.0), weight: 10),
      TweenSequenceItem(tween: Tween(begin:  8.0, end: -6.0), weight: 10),
      TweenSequenceItem(tween: Tween(begin: -6.0, end:  6.0), weight: 10),
      TweenSequenceItem(tween: Tween(begin:  6.0, end: -4.0), weight: 10),
      TweenSequenceItem(tween: Tween(begin: -4.0, end:  4.0), weight: 10),
      TweenSequenceItem(tween: Tween(begin:  4.0, end: -2.0), weight: 10),
      TweenSequenceItem(tween: Tween(begin: -2.0, end:  2.0), weight: 10),
      TweenSequenceItem(tween: Tween(begin:  2.0, end: -1.0), weight: 10),
      TweenSequenceItem(tween: Tween(begin: -1.0, end:  0.0), weight: 10),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.linear));

    _shakeCtrl.addStatusListener((s) {
      if (s == AnimationStatus.completed) setState(() => _shaking = false);
    });

    AudioEngine.init();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _diceCtrl.dispose();
    _floatCtrl.dispose();
    _shakeCtrl.dispose();
    _stepTimer?.cancel();
    _diceRollTimer?.cancel();
    super.dispose();
  }

  // ── Dice roll ─────────────────────────────────────────────────────────────
  void _handleRoll() {
    if (G.phase != GamePhase.awaitingRoll) return;
    AudioEngine.play('dice_roll');
    setState(() { G.phase = GamePhase.rolling; });
    _diceCtrl.reset();
    _diceCtrl.forward();

    // Animate dice face rapidly
    _diceRollTimer?.cancel();
    int tickCount = 0;
    _diceRollTimer = Timer.periodic(const Duration(milliseconds: 60), (t) {
      setState(() => _diceDisplay = Random().nextInt(6) + 1);
      tickCount++;
      if (tickCount >= 10) { t.cancel(); _diceRollTimer = null; }
    });

    Future.delayed(const Duration(milliseconds: 660), () {
      final roll = G.roll();
      setState(() { _diceDisplay = roll; });

      // Floating number pop
      _spawnFloat('+$roll');

      // Triple-six rule
      final newSixes = roll == 6 ? G.consecutiveSixes + 1 : 0;
      if (roll == 6 && G.consecutiveSixes >= 2) {
        G.consecutiveSixes = 0;
        G.statusText = "Triple-six! ${colorLabel(G.currentColor)} forfeits.";
        setState(() {});
        Future.delayed(const Duration(milliseconds: 1400), () {
          setState(() => G.advanceTurn());
        });
        return;
      }
      G.consecutiveSixes = newSixes;

      if (roll == 6) AudioEngine.play('bonus_six');

      final moves = G.computeMoves(G.currentColor, roll);
      if (moves.isEmpty) {
        G.phase = GamePhase.noMove;
        G.statusText = "No moves for ${colorLabel(G.currentColor)}";
        setState(() {});
        Future.delayed(const Duration(milliseconds: 2000), () {
          if (mounted) setState(() => G.advanceTurn());
        });
      } else if (moves.length == 1) {
        G.phase = GamePhase.awaitingPick;
        G.validMoves = moves;
        setState(() {
          G.statusText = "${colorLabel(G.currentColor)} rolled $roll";
        });
        Future.delayed(const Duration(milliseconds: 460), () {
          if (mounted) _executeMove(moves.first);
        });
      } else {
        G.phase = GamePhase.awaitingPick;
        G.validMoves = moves;
        setState(() {
          G.statusText = "${colorLabel(G.currentColor)} rolled $roll — pick a token";
        });
      }
    });
  }

  // ── Pick token ────────────────────────────────────────────────────────────
  void _handleTokenTap(PlayerColor color, int tokenId) {
    if (G.phase != GamePhase.awaitingPick) return;
    if (color != G.currentColor) return;
    final move = G.validMoves.where((m) => m.tokenId == tokenId).firstOrNull;
    if (move == null) return;
    G.validMoves = [];
    _executeMove(move);
  }

  // ── Execute move with step animation ─────────────────────────────────────
  void _executeMove(ValidMove move) {
    if (_animating) return;
    _animating = true;
    G.phase = GamePhase.animating;
    _pendingMove = move;
    _animColor = G.currentColor;
    _animPath  = G.buildPath(G.currentColor, move);
    _animStep  = 0;

    // Save current token position before applying so we can animate from it
    _runNextStep();
  }

  void _runNextStep() {
    if (_animStep >= _animPath.length) {
      _finishMove();
      return;
    }
    AudioEngine.play('token_step');
    setState(() { _animStep++; });
    _stepTimer = Timer(const Duration(milliseconds: 200), _runNextStep);
  }

  void _finishMove() {
    _stepTimer?.cancel();
    _animating = false;
    final color  = _animColor!;
    final move   = _pendingMove!;
    final roll   = G.diceValue;

    final captured = G.applyMove(color, move);

    if (captured) {
      AudioEngine.play('capture');
      _triggerShake();
    }

    if (move.toHome == 4) {
      AudioEngine.play('token_home');
    }

    if (G.checkWin(color)) {
      AudioEngine.play('victory');
      setState(() {});
      return;
    }

    final extra = (roll == 6) || captured;
    if (captured) {
      G.statusText = "${colorLabel(color)} captured a token! 💥";
      setState(() {});
      Future.delayed(const Duration(milliseconds: 700), () {
        if (mounted) setState(() => G.advanceTurn(extra: extra));
      });
    } else {
      setState(() => G.advanceTurn(extra: extra));
    }
    _animPath  = [];
    _animStep  = 0;
    _animColor = null;
    _pendingMove = null;
  }

  void _spawnFloat(String text) {
    setState(() { _floatLabel = text; _showFloat = true; });
    _floatCtrl.reset();
    _floatCtrl.forward().then((_) {
      if (mounted) setState(() => _showFloat = false);
    });
  }

  void _triggerShake() {
    setState(() => _shaking = true);
    _shakeCtrl.reset();
    _shakeCtrl.forward();
  }

  void _promptQuit() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _QuitDialog(onConfirm: () {
        Navigator.of(context).pop(); // pop dialog
        Navigator.of(context).pop(); // pop game screen
      }, onCancel: () => Navigator.of(context).pop()),
    );
  }

  // ── Canvas tap router ─────────────────────────────────────────────────────
  void _onBoardTap(Offset local, double boardSize) {
    final cellSize = boardSize / 15;

    // Convert to grid col, row
    final col = (local.dx / cellSize).floor();
    final row = (local.dy / cellSize).floor();

    // Centre dice zone: rows 6–8, cols 6–8
    if (G.phase == GamePhase.awaitingRoll &&
        row >= 6 && row <= 8 && col >= 6 && col <= 8) {
      _handleRoll();
      AudioEngine.play('tap');
      return;
    }

    // Token tap detection
    if (G.phase == GamePhase.awaitingPick) {
      final selIds = G.validMoves.map((m) => m.tokenId).toSet();
      final color  = G.currentColor;
      final tokens = G.players[color]!;

      for (final tok in tokens) {
        if (!selIds.contains(tok.id)) continue;
        final center = _tokenGridCenter(tok, color);
        if (center == null) continue;
        final dx = local.dx - center.dx * cellSize;
        final dy = local.dy - center.dy * cellSize;
        final dist = sqrt(dx * dx + dy * dy);
        if (dist <= cellSize * 0.45) {
          _handleTokenTap(color, tok.id);
          return;
        }
      }
    }
  }

  // Returns fractional (col, row) centre of token
  Offset? _tokenGridCenter(Token tok, PlayerColor color) {
    if (tok.status == TokenStatus.yard) {
      final slot = kYardSlots[color]![tok.id];
      return Offset(slot[1] + 0.5, slot[0] + 0.5);
    }
    if (tok.status == TokenStatus.board && tok.boardPos >= 0) {
      final cell = kTrack[tok.boardPos];
      return Offset(cell[1] + 0.5, cell[0] + 0.5);
    }
    if (tok.status == TokenStatus.board && tok.homePos >= 0) {
      final cell = kHomeCol[color]![tok.homePos];
      return Offset(cell[1] + 0.5, cell[0] + 0.5);
    }
    return null;
  }

  // Returns current animated position during stepping
  Offset? _animTokenCenter(Token tok, PlayerColor color) {
    if (_animating && _animColor == color &&
        _pendingMove?.tokenId == tok.id && _animPath.isNotEmpty) {
      final stepIdx = (_animStep - 1).clamp(0, _animPath.length - 1);
      final cell = _animPath[stepIdx];
      return Offset(cell[1] + 0.5, cell[0] + 0.5);
    }
    return _tokenGridCenter(tok, color);
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final boardSize  = screenSize.width.clamp(200.0, screenSize.height).toDouble();

    return Scaffold(
      backgroundColor: AppColors.appBg,
      body: Stack(
        children: [
          // ── Full-screen background ───────────────────────────────────────
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter, end: Alignment.bottomCenter,
                colors: [Color(0xFF1565C0), Color(0xFF1148A8),
                         Color(0xFF0D3E94), Color(0xFF0A3380)],
              ),
            ),
          ),

          // ── Board centred, edge-to-edge ──────────────────────────────────
          Center(
            child: AnimatedBuilder(
              animation: _shakeAnim,
              builder: (_, child) => Transform.translate(
                offset: Offset(_shaking ? _shakeAnim.value : 0, 0),
                child: child,
              ),
              child: SizedBox.square(
                dimension: boardSize,
                child: GestureDetector(
                  onTapDown: (d) => _onBoardTap(d.localPosition, boardSize),
                  child: AnimatedBuilder(
                    animation: Listenable.merge([_pulseAnim, _diceSpinAnim, _floatAlpha]),
                    builder: (_, __) => CustomPaint(
                      size: Size.square(boardSize),
                      painter: LudoBoardPainter(
                        engine:        G,
                        pulseValue:    _pulseAnim.value,
                        diceDisplay:   _diceDisplay,
                        diceSpinAngle: G.phase == GamePhase.rolling ? _diceSpinAnim.value : 0,
                        animColor:     _animColor,
                        animTokenId:   _pendingMove?.tokenId,
                        animCenter:    _animPath.isNotEmpty && _animStep > 0
                            ? Offset(
                                _animPath[(_animStep-1).clamp(0,_animPath.length-1)][1] + 0.5,
                                _animPath[(_animStep-1).clamp(0,_animPath.length-1)][0] + 0.5)
                            : null,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ── Floating number pop ──────────────────────────────────────────
          if (_showFloat)
            AnimatedBuilder(
              animation: _floatCtrl,
              builder: (_, __) {
                final cx = screenSize.width  / 2;
                final cy = screenSize.height / 2;
                return Positioned(
                  left:  cx - 60,
                  top:   cy + _floatY.value - 30,
                  child: Opacity(
                    opacity: _floatAlpha.value.clamp(0.0, 1.0),
                    child: Transform.scale(
                      scale: _floatScale.value,
                      child: Text(_floatLabel,
                        style: TextStyle(
                          fontSize: 28, fontWeight: FontWeight.w900,
                          foreground: Paint()
                            ..shader = const LinearGradient(colors: [
                              Colors.white, AppColors.gold, Color(0xFFC49000)])
                            .createShader(const Rect.fromLTWH(0,0,120,50)),
                          shadows: const [Shadow(color: Colors.black54, blurRadius: 8, offset: Offset(0,3))],
                        )),
                    ),
                  ),
                );
              },
            ),

          // ── TOP HUD ──────────────────────────────────────────────────────
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            left: 10, right: 10,
            child: _GlassPanel(
              child: Row(
                children: [
                  _IconBtn(
                    icon: Icons.exit_to_app,
                    label: 'QUIT',
                    onTap: _promptQuit),
                  const Spacer(),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ShaderMask(
                        shaderCallback: (b) => const LinearGradient(
                          colors: [Colors.white, AppColors.gold])
                          .createShader(b),
                        child: const Text('LUDO KING',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900,
                            letterSpacing: 2, fontFamily: 'serif'))),
                      const Text('REMASTERED',
                        style: TextStyle(fontSize: 8, letterSpacing: 5,
                          color: AppColors.gold)),
                    ],
                  ),
                  const Spacer(),
                  // Mute toggle
                  _IconBtn(
                    icon: AudioEngine.muted ? Icons.volume_off : Icons.volume_up,
                    label: AudioEngine.muted ? 'MUTE' : 'SOUND',
                    onTap: () { setState(() => AudioEngine.toggle()); AudioEngine.play('tap'); }),
                ],
              ),
            ),
          ),

          // ── STATUS HUD ───────────────────────────────────────────────────
          Positioned(
            top: MediaQuery.of(context).padding.top + 72,
            left: 0, right: 0,
            child: Center(
              child: _GlassPanel(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
                borderRadius: 20,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(G.statusText,
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                      textAlign: TextAlign.center),
                    if (G.mode == GameMode.cheat && G.cheatColor != null)
                      Text(
                        '🎭 Cheat: ${colorLabel(G.cheatColor!)} boosted',
                        style: TextStyle(
                          fontSize: 9, color: ludoColor(G.cheatColor!),
                          fontWeight: FontWeight.bold),
                      ),
                  ],
                ),
              ),
            ),
          ),

          // ── PLAYER CHIPS HUD (bottom) ─────────────────────────────────────
          Positioned(
            bottom: MediaQuery.of(context).padding.bottom + 8,
            left: 10, right: 10,
            child: _GlassPanel(
              child: Row(
                children: G.colors.map((c) {
                  final isActive = c == G.currentColor && G.phase != GamePhase.over;
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: _PlayerChip(
                        color: c,
                        tokens: G.players[c]!,
                        isActive: isActive,
                        hasWon: G.hasWon(c),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),

          // ── VICTORY OVERLAY ───────────────────────────────────────────────
          if (G.phase == GamePhase.over && G.winner != null)
            _VictoryOverlay(
              winner: G.winner!,
              onPlayAgain: () {
                final engine = GameEngine(
                  colors: G.colors, mode: G.mode, cheatColor: G.cheatColor);
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => GameScreen(engine: engine)));
              },
              onMainMenu: () => Navigator.of(context).pop(),
            ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// BOARD PAINTER — Custom Canvas rendering of the entire Ludo board
// ═══════════════════════════════════════════════════════════════════════════

class LudoBoardPainter extends CustomPainter {
  final GameEngine engine;
  final double pulseValue;
  final int    diceDisplay;
  final double diceSpinAngle;
  final PlayerColor? animColor;
  final int?         animTokenId;
  final Offset?      animCenter;  // fractional grid coords during anim

  LudoBoardPainter({
    required this.engine,
    required this.pulseValue,
    required this.diceDisplay,
    required this.diceSpinAngle,
    this.animColor,
    this.animTokenId,
    this.animCenter,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final c  = size.width / 15;   // cell size
    final h  = c / 2;             // half cell

    _drawBoardBackground(canvas, size, c);
    _drawYardZones(canvas, c);
    _drawTrackCells(canvas, c);
    _drawEntryArrows(canvas, c);
    _drawHomeColumns(canvas, c);
    _drawCenterDice(canvas, c, size);
    _drawGridLines(canvas, size, c);
    _drawBoardBorder(canvas, size);
    _drawAllTokens(canvas, c);
  }

  // ── Board background ───────────────────────────────────────────────────
  void _drawBoardBackground(Canvas canvas, Size size, double c) {
    final paint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFFFEFCF5), Color(0xFFFAF6EA), Color(0xFFF5EDCC)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    final rrect = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, size.width, size.height), Radius.circular(10));
    canvas.drawRRect(rrect, paint);

    // Vignette
    final vigPaint = Paint()
      ..shader = RadialGradient(
        colors: [Colors.transparent, Colors.black.withOpacity(0.055)],
        radius: 0.72,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRRect(rrect, vigPaint);
  }

  // ── Yard zones (6×6 coloured quadrants) ───────────────────────────────
  void _drawYardZones(Canvas canvas, double c) {
    _drawYard(canvas, c, 0,  0,  PlayerColor.red);
    _drawYard(canvas, c, 0,  9,  PlayerColor.green);
    _drawYard(canvas, c, 9,  9,  PlayerColor.yellow);
    _drawYard(canvas, c, 9,  0,  PlayerColor.blue);
  }

  void _drawYard(Canvas canvas, double c, int startR, int startC, PlayerColor pc) {
    final col  = ludoColor(pc);
    final colD = ludoColorDark(pc);
    final colL = ludoColorLight(pc);
    final x = startC * c, y = startR * c;
    final sz = c * 6, rad = c * 0.32;

    // Gradient fill
    final bodyPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [colL, col, colD],
        stops: const [0, 0.45, 1],
      ).createShader(Rect.fromLTWH(x, y, sz, sz));
    canvas.drawRRect(RRect.fromRectAndRadius(
      Rect.fromLTWH(x, y, sz, sz), Radius.circular(rad)), bodyPaint);

    // Gloss sheen
    final sheenPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: [Colors.white.withOpacity(0.30), Colors.transparent],
      ).createShader(Rect.fromLTWH(x, y, sz, sz * 0.52));
    canvas.drawRRect(RRect.fromRectAndRadius(
      Rect.fromLTWH(x, y, sz, sz * 0.52), Radius.circular(rad)), sheenPaint);

    // Inner white housing
    final pad = c * 0.68;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(x+pad, y+pad, sz-pad*2, sz-pad*2), Radius.circular(c*0.22)),
      Paint()..color = Colors.white.withOpacity(0.93));
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(x+pad, y+pad, sz-pad*2, sz-pad*2), Radius.circular(c*0.22)),
      Paint()..color = col.withOpacity(0.28)..style = PaintingStyle.stroke..strokeWidth = 1);

    // Slot rings
    for (final slot in kYardSlots[pc]!) {
      final cx = slot[1]*c + c/2, cy = slot[0]*c + c/2, sr = c*0.36;
      // Shadow ellipse
      canvas.drawOval(
        Rect.fromCenter(center: Offset(cx+1, cy+3), width: sr*1.76, height: sr*0.66),
        Paint()..color = Colors.black.withOpacity(0.18));
      // Slot ring
      canvas.drawCircle(Offset(cx, cy), sr, Paint()..color = col.withOpacity(0.16));
      canvas.drawCircle(Offset(cx, cy), sr,
        Paint()..color = col.withOpacity(0.62)..style = PaintingStyle.stroke..strokeWidth = 2);
      canvas.drawCircle(Offset(cx, cy), sr*0.52,
        Paint()..color = col.withOpacity(0.24)..style = PaintingStyle.stroke..strokeWidth = 1);
    }
  }

  // ── Track cells ────────────────────────────────────────────────────────
  void _drawTrackCells(Canvas canvas, double c) {
    for (int i = 0; i < kTrack.length; i++) {
      final r = kTrack[i][0], cl = kTrack[i][1];
      final x = cl*c + 1, y = r*c + 1, sz = c - 2;
      if (kSafeCells.contains(i)) {
        canvas.drawRect(Rect.fromLTWH(x, y, sz, sz),
          Paint()..color = const Color(0xFFFFF9E0));
        _drawStar(canvas, Offset(cl*c + c/2, r*c + c/2), c*0.29, c*0.13);
      } else {
        canvas.drawRect(Rect.fromLTWH(x, y, sz, sz),
          Paint()..color = const Color(0xFFFEFEFE));
        canvas.drawRect(Rect.fromLTWH(x+0.5, y+0.5, sz-1, sz-1),
          Paint()..color = const Color(0x66C3B99B)..style = PaintingStyle.stroke..strokeWidth = 0.5);
      }
    }
  }

  // ── 5-point gold star ──────────────────────────────────────────────────
  void _drawStar(Canvas canvas, Offset centre, double outerR, double innerR) {
    final path = Path();
    const points = 5;
    for (int i = 0; i < points * 2; i++) {
      final r     = i.isEven ? outerR : innerR;
      final angle = (i * pi / points) - pi / 2;
      final p = Offset(centre.dx + r * cos(angle), centre.dy + r * sin(angle));
      if (i == 0) path.moveTo(p.dx, p.dy); else path.lineTo(p.dx, p.dy);
    }
    path.close();

    // Shadow
    canvas.drawShadow(path, Colors.orange.withOpacity(0.40), 2, false);

    // Gradient fill
    canvas.drawPath(path, Paint()
      ..shader = RadialGradient(
        center: const Alignment(0, -0.3),
        radius: 1.0,
        colors: const [Color(0xFFFFF176), Color(0xFFFFC107), Color(0xFFE65100)],
        stops: const [0, 0.5, 1],
      ).createShader(Rect.fromCircle(center: centre, radius: outerR)));

    // Stroke
    canvas.drawPath(path,
      Paint()..color = const Color(0xFFC77700)..style = PaintingStyle.stroke..strokeWidth = 0.8);

    // Glint
    canvas.drawCircle(
      Offset(centre.dx - outerR*0.24, centre.dy - outerR*0.28), outerR*0.12,
      Paint()..color = Colors.white.withOpacity(0.62));
  }

  // ── Entry arrows ───────────────────────────────────────────────────────
  void _drawEntryArrows(Canvas canvas, double c) {
    kEntry.forEach((pc, idx) {
      final r = kTrack[idx][0], cl = kTrack[idx][1];
      final col = ludoColor(pc);
      canvas.drawRect(Rect.fromLTWH(cl*c+1, r*c+1, c-2, c-2),
        Paint()..color = col.withOpacity(0.80));

      // Gloss
      canvas.drawRect(Rect.fromLTWH(cl*c+1, r*c+1, c-2, (c-2)*0.5),
        Paint()..shader = LinearGradient(
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Colors.white.withOpacity(0.32), Colors.transparent],
        ).createShader(Rect.fromLTWH(cl*c+1, r*c+1, c-2, (c-2)*0.5)));

      // Arrow text
      final tp = TextPainter(
        text: TextSpan(text: '▶',
          style: TextStyle(fontSize: c*0.38, color: Colors.white.withOpacity(0.90))),
        textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, Offset(cl*c + c/2 - tp.width/2, r*c + c/2 - tp.height/2));
    });
  }

  // ── Home column gradient lanes ─────────────────────────────────────────
  void _drawHomeColumns(Canvas canvas, double c) {
    kHomeCol.forEach((pc, cells) {
      final col  = ludoColor(pc);
      final colL = ludoColorLight(pc);
      final colD = ludoColorDark(pc);
      for (int i = 0; i < cells.length; i++) {
        final r = cells[i][0], cl = cells[i][1];
        final alpha = 0.30 + i * 0.13;
        canvas.drawRect(
          Rect.fromLTWH(cl*c+1, r*c+1, c-2, c-2),
          Paint()..shader = LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [colL.withOpacity(alpha+0.10), colD.withOpacity(alpha)],
          ).createShader(Rect.fromLTWH(cl*c+1, r*c+1, c-2, c-2)));
        canvas.drawRect(
          Rect.fromLTWH(cl*c+1.5, r*c+1.5, c-3, c-3),
          Paint()..color = colD.withOpacity(0.18)..style = PaintingStyle.stroke..strokeWidth = 0.5);
      }
    });
  }

  // ── Centre dice (overlays home triangle intersection) ─────────────────
  void _drawCenterDice(Canvas canvas, double c, Size size) {
    final cx = 7.5 * c, cy = 7.5 * c;
    final h  = c * 1.5;

    // Four coloured triangles
    final tris = [
      (PlayerColor.red,    [Offset(cx-h,cy-h), Offset(cx+h,cy-h), Offset(cx,cy)]),
      (PlayerColor.green,  [Offset(cx+h,cy-h), Offset(cx+h,cy+h), Offset(cx,cy)]),
      (PlayerColor.yellow, [Offset(cx+h,cy+h), Offset(cx-h,cy+h), Offset(cx,cy)]),
      (PlayerColor.blue,   [Offset(cx-h,cy+h), Offset(cx-h,cy-h), Offset(cx,cy)]),
    ];

    for (final (pc, pts) in tris) {
      final col  = ludoColor(pc);
      final colL = ludoColorLight(pc);
      final colD = ludoColorDark(pc);
      final path = Path()
        ..moveTo(pts[0].dx, pts[0].dy)
        ..lineTo(pts[1].dx, pts[1].dy)
        ..lineTo(pts[2].dx, pts[2].dy)
        ..close();
      canvas.drawPath(path, Paint()
        ..shader = RadialGradient(
          colors: [colL, col, colD], stops: const [0, 0.55, 1],
        ).createShader(Rect.fromCircle(center: Offset(cx,cy), radius: h*1.35)));
      canvas.drawPath(path,
        Paint()..color = Colors.white.withOpacity(0.22)..style = PaintingStyle.stroke..strokeWidth = 0.8);
    }

    // White base circle
    canvas.save();
    canvas.drawShadow(
      Path()..addOval(Rect.fromCircle(center: Offset(cx,cy), radius: c*0.74)),
      Colors.black.withOpacity(0.42), 8, false);
    canvas.drawCircle(Offset(cx,cy), c*0.74,
      Paint()..color = const Color(0xFFFFFDE7));
    canvas.restore();

    // Gold rings
    canvas.drawCircle(Offset(cx,cy), c*0.74,
      Paint()..color = const Color(0xFF96780A).withOpacity(0.78)..style = PaintingStyle.stroke..strokeWidth = 2.5);
    canvas.drawCircle(Offset(cx,cy), c*0.58,
      Paint()..color = const Color(0xFF96780A).withOpacity(0.38)..style = PaintingStyle.stroke..strokeWidth = 1);

    // ── 3D Dice body ────────────────────────────────────────────────────
    final dw = c * 2.2, dh = c * 2.2, dr = c * 0.28;
    final dx = cx - dw/2, dy = cy - dh/2;

    canvas.save();
    if (diceSpinAngle != 0) {
      canvas.translate(cx, cy);
      canvas.rotate(sin(diceSpinAngle) * 0.08);
      canvas.translate(-cx, -cy);
    }

    // Dice shadow
    canvas.drawShadow(
      Path()..addRRect(RRect.fromRectAndRadius(
        Rect.fromLTWH(dx, dy, dw, dh), Radius.circular(dr))),
      Colors.black.withOpacity(0.55), 10, false);

    // Dice body gradient
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(dx,dy,dw,dh), Radius.circular(dr)),
      Paint()..shader = LinearGradient(
        begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: const [Color(0xFFFEFAE8), Color(0xFFF5EECE),
                       Color(0xFFE8D88A), Color(0xFFC9A820)],
        stops: const [0, 0.4, 0.8, 1],
      ).createShader(Rect.fromLTWH(dx,dy,dw,dh)));

    // Dice border
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(dx,dy,dw,dh), Radius.circular(dr)),
      Paint()..color = const Color(0xFFB8860B)..style = PaintingStyle.stroke..strokeWidth = 1.8);

    // Gloss sheen
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(dx,dy,dw,dh*0.48), Radius.circular(dr)),
      Paint()..shader = LinearGradient(
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: [Colors.white.withOpacity(0.72), Colors.transparent],
      ).createShader(Rect.fromLTWH(dx,dy,dw,dh*0.48)));

    // Bottom bevel
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(dx,dy+dh*0.72,dw,dh*0.28), Radius.circular(dr)),
      Paint()..shader = LinearGradient(
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: [Colors.transparent, Colors.black.withOpacity(0.16)],
      ).createShader(Rect.fromLTWH(dx,dy+dh*0.72,dw,dh*0.28)));

    // Pips
    final pips     = kDicePips[diceDisplay.clamp(1, 6)] ?? [];
    final pipStep  = dw * 0.28;
    final pipStart = Offset(dx + dw*0.22, dy + dh*0.22);
    final pipR     = dw * 0.075;

    for (int gi = 0; gi < 9; gi++) {
      final gr = gi ~/ 3, gc = gi % 3;
      final px = pipStart.dx + gc*pipStep, py = pipStart.dy + gr*pipStep;
      if (pips.contains(gi)) {
        canvas.drawShadow(
          Path()..addOval(Rect.fromCircle(center: Offset(px,py), radius: pipR)),
          Colors.black.withOpacity(0.65), 1.5, false);
        canvas.drawCircle(Offset(px,py), pipR, Paint()
          ..shader = RadialGradient(
            center: const Alignment(-0.3, -0.3),
            colors: const [Color(0xFF5C3A1E), Color(0xFF2A0800), Color(0xFF1A0500)],
            stops: const [0, 0.7, 1],
          ).createShader(Rect.fromCircle(center: Offset(px,py), radius: pipR)));
      }
    }
    canvas.restore();

    // Await-roll pulse ring + hint
    if (engine.phase == GamePhase.awaitingRoll) {
      final pulseAlpha = 0.40 + pulseValue * 0.55;
      final pulseWidth = 2.0 + pulseValue * 2.0;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(dx-3, dy-3, dw+6, dh+6), Radius.circular(dr+3)),
        Paint()..color = AppColors.gold.withOpacity(pulseAlpha)
               ..style = PaintingStyle.stroke..strokeWidth = pulseWidth);

      const hint = 'TAP TO ROLL';
      final tp = TextPainter(
        text: TextSpan(text: hint,
          style: TextStyle(
            fontSize: c*0.24, fontWeight: FontWeight.w900,
            color: AppColors.gold.withOpacity(0.55 + pulseValue*0.45))),
        textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, Offset(cx - tp.width/2, dy + dh + c*0.12));
    }
  }

  // ── Grid lines ─────────────────────────────────────────────────────────
  void _drawGridLines(Canvas canvas, Size size, double c) {
    final paint = Paint()
      ..color = const Color(0x33968255)..strokeWidth = 0.5;
    for (int i = 0; i <= 15; i++) {
      canvas.drawLine(Offset(i*c, 0), Offset(i*c, size.height), paint);
      canvas.drawLine(Offset(0, i*c), Offset(size.width, i*c), paint);
    }
  }

  // ── Board border ────────────────────────────────────────────────────────
  void _drawBoardBorder(Canvas canvas, Size size) {
    final rrect = RRect.fromRectAndRadius(
      Rect.fromLTWH(1.5, 1.5, size.width-3, size.height-3), const Radius.circular(9));
    canvas.drawRRect(rrect,
      Paint()..color = const Color(0xFF5D4037)..style = PaintingStyle.stroke..strokeWidth = 3);
    final rrect2 = RRect.fromRectAndRadius(
      Rect.fromLTWH(2.5, 2.5, size.width-5, size.height-5), const Radius.circular(8));
    canvas.drawRRect(rrect2,
      Paint()..color = const Color(0xFFD4A017).withOpacity(0.55)
             ..style = PaintingStyle.stroke..strokeWidth = 1);
  }

  // ── All tokens ─────────────────────────────────────────────────────────
  void _drawAllTokens(Canvas canvas, double c) {
    final selIds = engine.validMoves.map((m) => m.tokenId).toSet();
    final isPick = engine.phase == GamePhase.awaitingPick;

    engine.colors.forEach((color) {
      engine.players[color]!.forEach((tok) {
        if (tok.status == TokenStatus.home) return;

        final selectable = isPick && selIds.contains(tok.id) && color == engine.currentColor;
        final isAnimating = animColor == color && animTokenId == tok.id && animCenter != null;

        Offset? center;
        if (isAnimating) {
          center = Offset(animCenter!.dx * c, animCenter!.dy * c);
        } else {
          center = _resolveTokenCenter(tok, color, c);
        }
        if (center == null) return;

        _drawToken(canvas, center, color, selectable, c*0.31);
      });
    });
  }

  Offset? _resolveTokenCenter(Token tok, PlayerColor color, double c) {
    if (tok.status == TokenStatus.yard) {
      final slot = kYardSlots[color]![tok.id];
      return Offset(slot[1]*c + c/2, slot[0]*c + c/2);
    }
    if (tok.status == TokenStatus.board && tok.boardPos >= 0) {
      final cell = kTrack[tok.boardPos];
      // Stack offset for multiple tokens on same cell
      final stacked = engine.players[color]!
          .where((t) => t.status == TokenStatus.board &&
                         t.boardPos == tok.boardPos && t.boardPos >= 0)
          .toList();
      final si = stacked.indexWhere((t) => t.id == tok.id);
      const offsets = [Offset(-0.14,-0.14), Offset(0.14,-0.14),
                       Offset(-0.14, 0.14), Offset(0.14, 0.14)];
      final off = stacked.length > 1 ? (offsets.length > si ? offsets[si] : Offset.zero) : Offset.zero;
      return Offset(cell[1]*c + c/2 + off.dx*c, cell[0]*c + c/2 + off.dy*c);
    }
    if (tok.status == TokenStatus.board && tok.homePos >= 0) {
      final cell = kHomeCol[color]![tok.homePos];
      return Offset(cell[1]*c + c/2, cell[0]*c + c/2);
    }
    return null;
  }

  // ── 9-layer 3D pawn ────────────────────────────────────────────────────
  void _drawToken(Canvas canvas, Offset centre, PlayerColor pc,
                  bool selectable, double baseR) {
    final col  = ludoColor(pc);
    final colD = ludoColorDark(pc);
    final colL = ludoColorLight(pc);
    final scale  = selectable ? 1.0 + pulseValue * 0.16 : 1.0;
    final radius = baseR * scale;

    // 1. Glow halo
    if (selectable) {
      final ga = 0.30 + pulseValue * 0.44;
      final gR = radius * (1.78 + pulseValue * 0.55);
      canvas.drawCircle(centre, gR, Paint()
        ..shader = RadialGradient(
          colors: [col.withOpacity(ga), col.withOpacity(ga*0.36), Colors.transparent],
          stops: const [0, 0.5, 1],
        ).createShader(Rect.fromCircle(center: centre, radius: gR)));
    }

    // 2. Drop shadow — spec: shadowBlur=6, shadowOffsetY=4
    canvas.drawShadow(
      Path()..addOval(Rect.fromCircle(center: centre.translate(radius*0.06, 4), radius: radius)),
      Colors.black.withOpacity(0.45), 6, false);

    // 3. Dark outer ring
    canvas.drawCircle(centre, radius, Paint()..color = colD);

    // 4. 3D sphere body
    final bodyR = radius * 0.88;
    final hO    = radius * 0.24;
    canvas.drawCircle(centre, bodyR, Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.55, -0.55),
        radius: 1.0,
        colors: [colL, col, colD, const Color(0xB3000000)],
        stops: const [0, 0.38, 0.80, 1],
      ).createShader(Rect.fromCircle(center: centre, radius: bodyR)));

    // 5. White inner ring accent
    canvas.drawCircle(centre, radius * 0.60, Paint()
      ..color = Colors.white.withOpacity(0.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = radius * 0.14);

    // 6. Inner face fill
    canvas.drawCircle(centre, radius * 0.60 * 0.82, Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.28, -0.28),
        radius: 1.0,
        colors: [colL.withOpacity(0.60), col.withOpacity(0.10)],
      ).createShader(Rect.fromCircle(center: centre, radius: radius*0.60*0.82)));

    // 7. Primary specular
    final specCentre = centre.translate(-radius*0.30, -radius*0.30);
    canvas.drawCircle(specCentre, radius*0.38, Paint()
      ..shader = RadialGradient(
        colors: [Colors.white.withOpacity(0.92),
                 Colors.white.withOpacity(0.28),
                 Colors.transparent],
        stops: const [0, 0.6, 1],
      ).createShader(Rect.fromCircle(center: specCentre, radius: radius*0.38)));

    // 8. Micro glint
    canvas.drawCircle(
      centre.translate(-radius*0.10, -radius*0.44), radius*0.10,
      Paint()..color = Colors.white.withOpacity(0.58));

    // 9. Selection rings
    if (selectable) {
      final bA = 0.65 + pulseValue * 0.35;
      canvas.drawCircle(centre, radius + radius*0.16, Paint()
        ..color = Colors.white.withOpacity(bA)
        ..style = PaintingStyle.stroke
        ..strokeWidth = radius * 0.17 + pulseValue * radius * 0.08);
      canvas.drawCircle(centre, radius + radius*0.36, Paint()
        ..color = col.withOpacity(0.56 * pulseValue)
        ..style = PaintingStyle.stroke
        ..strokeWidth = radius * 0.11);
    }
  }

  @override
  bool shouldRepaint(LudoBoardPainter old) =>
    old.pulseValue != pulseValue ||
    old.diceDisplay != diceDisplay ||
    old.diceSpinAngle != diceSpinAngle ||
    old.animStep != animStep ||
    old.animCenter != animCenter ||
    true; // always repaint during active game to keep dice hints live

  // expose animStep for shouldRepaint
  int get animStep => 0;
}

// ═══════════════════════════════════════════════════════════════════════════
// HUD WIDGETS
// ═══════════════════════════════════════════════════════════════════════════

class _GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final double borderRadius;

  const _GlassPanel({
    required this.child,
    this.padding,
    this.borderRadius = 14,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: Container(
        padding: padding ?? const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xB80A143C),
          borderRadius: BorderRadius.circular(borderRadius),
          border: Border.all(color: Colors.white.withOpacity(0.15), width: 1),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.50),
            blurRadius: 24, offset: const Offset(0, 4))],
        ),
        child: child,
      ),
    );
  }
}

class _PlayerChip extends StatelessWidget {
  final PlayerColor color;
  final List<Token> tokens;
  final bool isActive, hasWon;

  const _PlayerChip({
    required this.color, required this.tokens,
    required this.isActive, required this.hasWon});

  @override
  Widget build(BuildContext context) {
    final col = ludoColor(color);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutBack,
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      decoration: BoxDecoration(
        color: isActive ? col.withOpacity(0.18) : Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isActive ? col : col.withOpacity(0.25),
          width: isActive ? 2 : 1.5),
        boxShadow: isActive ? [BoxShadow(color: col.withOpacity(0.45),
          blurRadius: 12, spreadRadius: 1)] : [],
      ),
      transform: isActive
          ? (Matrix4.identity()..translate(0.0, -3.0)..scale(1.04))
          : Matrix4.identity(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 7, height: 7,
              decoration: BoxDecoration(color: col, shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: col, blurRadius: 5)])),
            const SizedBox(width: 3),
            Text(colorLabel(color),
              style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800,
                color: isActive ? col : Colors.white.withOpacity(0.55))),
          ]),
          const SizedBox(height: 3),
          Row(mainAxisSize: MainAxisSize.min,
            children: tokens.map((t) {
              Color bg;
              if (t.status == TokenStatus.home) bg = col;
              else if (t.status == TokenStatus.board) bg = col.withOpacity(0.75);
              else bg = col.withOpacity(0.22);
              return Padding(padding: const EdgeInsets.symmetric(horizontal: 1),
                child: Container(width: 10, height: 10,
                  decoration: BoxDecoration(color: bg, shape: BoxShape.circle,
                    border: Border.all(color: col.withOpacity(0.55)),
                    boxShadow: t.status == TokenStatus.home
                      ? [BoxShadow(color: col, blurRadius: 5)] : [])));
            }).toList()),
          const SizedBox(height: 2),
          Text(
            isActive ? '▸ TURN' : (hasWon ? '✓ WON' : ''),
            style: TextStyle(fontSize: 7, fontWeight: FontWeight.w900,
              color: isActive ? col : col.withOpacity(0.65))),
        ],
      ),
    );
  }
}

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _IconBtn({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.12),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white.withOpacity(0.28), width: 1.5)),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 18, color: Colors.white),
        const SizedBox(height: 1),
        Text(label, style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w800,
          letterSpacing: 0.5, color: Color(0xCCFFFFFF))),
      ]),
    ),
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// DIALOGS & OVERLAYS
// ═══════════════════════════════════════════════════════════════════════════

class _QuitDialog extends StatelessWidget {
  final VoidCallback onConfirm, onCancel;
  const _QuitDialog({required this.onConfirm, required this.onCancel});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF1A3A8A), Color(0xFF0E2860), Color(0xFF0A1E50)]),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.gold.withOpacity(0.40), width: 1.5),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.80),
            blurRadius: 40, offset: const Offset(0, 16))]),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('🚪', style: TextStyle(fontSize: 42)),
          const SizedBox(height: 8),
          const Text('Quit Match?',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900,
              color: AppColors.gold, letterSpacing: 1)),
          const SizedBox(height: 12),
          Text('Are you sure?\nYour progress will be lost.',
            style: TextStyle(fontSize: 13.5, color: Colors.white.withOpacity(0.60),
              height: 1.55),
            textAlign: TextAlign.center),
          const SizedBox(height: 22),
          Row(children: [
            Expanded(child: _DialogBtn(
              label: 'Continue', onTap: onCancel,
              bg: Colors.white.withOpacity(0.12),
              border: Colors.white.withOpacity(0.22))),
            const SizedBox(width: 10),
            Expanded(child: _DialogBtn(
              label: 'Yes, Quit', onTap: onConfirm,
              bg: const Color(0xFFD32F2F),
              border: const Color(0xFFFF1744))),
          ]),
        ]),
      ),
    );
  }
}

class _DialogBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color bg, border;
  const _DialogBtn({required this.label, required this.onTap,
    required this.bg, required this.border});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 13),
      decoration: BoxDecoration(
        color: bg, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: border, width: 1.5)),
      child: Text(label,
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900,
          letterSpacing: 1, color: Colors.white)),
    ),
  );
}

class _VictoryOverlay extends StatefulWidget {
  final PlayerColor winner;
  final VoidCallback onPlayAgain, onMainMenu;
  const _VictoryOverlay({
    required this.winner, required this.onPlayAgain, required this.onMainMenu});

  @override
  State<_VictoryOverlay> createState() => _VictoryOverlayState();
}

class _VictoryOverlayState extends State<_VictoryOverlay>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale, _crown;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _crown = Tween(begin: -5.0, end: 5.0).animate(
      CurvedAnimation(parent: AnimationController(vsync: this,
        duration: const Duration(milliseconds: 800))..repeat(reverse: true),
        curve: Curves.easeInOut));
    _ctrl.forward();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final col  = ludoColor(widget.winner);
    final colD = ludoColorDark(widget.winner);
    final colL = ludoColorLight(widget.winner);

    return Container(
      color: Colors.black.withOpacity(0.88),
      child: Center(
        child: ScaleTransition(
          scale: _scale,
          child: Container(
            width: min(MediaQuery.of(context).size.width * 0.95, 390),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: [Color(0xFF1A3A8A), Color(0xFF0E2260), Color(0xFF08142A)]),
              borderRadius: BorderRadius.circular(26),
              border: Border.all(color: AppColors.gold.withOpacity(0.50), width: 2),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.85),
                blurRadius: 50, offset: const Offset(0, 20))]),
            child: Stack(children: [
              // Radial shine
              Positioned.fill(child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(26),
                  gradient: RadialGradient(
                    center: const Alignment(0, -0.7),
                    radius: 0.9,
                    colors: [AppColors.gold.withOpacity(0.14), Colors.transparent])))),
              Padding(
                padding: const EdgeInsets.all(28),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('♛',
                    style: TextStyle(fontSize: 56, color: AppColors.gold,
                      shadows: [Shadow(color: AppColors.gold, blurRadius: 20)])),
                  const SizedBox(height: 6),
                  Text('${colorLabel(widget.winner)} Wins! 🏆',
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900,
                      fontFamily: 'serif', color: col, letterSpacing: 2)),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [colD, col, colL]),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(color: col.withOpacity(0.40), blurRadius: 16)]),
                    child: Text('👑  ${colorLabel(widget.winner)} Player is the King!  👑',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: Colors.white,
                        shadows: [Shadow(color: Colors.black45, blurRadius: 5)]))),
                  const SizedBox(height: 8),
                  const Text('All tokens safely home 🏠',
                    style: TextStyle(fontSize: 13, color: Color(0x99FFFFFF))),
                  const SizedBox(height: 22),
                  _VBtn(
                    label: '▶  Play Again', color: col,
                    onTap: widget.onPlayAgain),
                  const SizedBox(height: 10),
                  _VBtn(
                    label: '⬅  Main Menu',
                    color: Colors.white.withOpacity(0.12),
                    textColor: Colors.white,
                    border: Colors.white.withOpacity(0.25),
                    onTap: widget.onMainMenu),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

class _VBtn extends StatelessWidget {
  final String label;
  final Color color;
  final Color? textColor, border;
  final VoidCallback onTap;
  const _VBtn({required this.label, required this.color,
    this.textColor, this.border, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: color, borderRadius: BorderRadius.circular(14),
        border: border != null ? Border.all(color: border!, width: 1.5) : null),
      child: Text(label,
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900,
          letterSpacing: 1.5, color: textColor ?? Colors.black)),
    ),
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// SETUP SCREEN SUB-WIDGETS
// ═══════════════════════════════════════════════════════════════════════════

class _Divider extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Container(width: 50, height: 1.5,
        color: AppColors.gold.withOpacity(0.7)),
      const Padding(padding: EdgeInsets.symmetric(horizontal: 10),
        child: Text('✦', style: TextStyle(color: AppColors.gold, fontSize: 14))),
      Container(width: 50, height: 1.5,
        color: AppColors.gold.withOpacity(0.7)),
    ],
  );
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) => Text(text,
    style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800,
      letterSpacing: 3, color: Color(0xCCFFDC50)),
    textAlign: TextAlign.center);
}

class _ChipButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _ChipButton({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      height: 50, alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: selected
          ? const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [Color(0xFFFFD740), Color(0xFFC49000)])
          : null,
        color: selected ? null : Colors.white.withOpacity(0.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: selected ? AppColors.gold : Colors.white.withOpacity(0.18),
          width: selected ? 0 : 1.5),
        boxShadow: selected ? [const BoxShadow(color: Color(0x80FFD700),
          blurRadius: 12, offset: Offset(0, 4))] : []),
      child: Text(label,
        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900,
          color: selected ? const Color(0xFF0A2000) : Colors.white.withOpacity(0.65))),
    ),
  );
}

class _ColorDot extends StatelessWidget {
  final Color color;
  const _ColorDot({required this.color});

  @override
  Widget build(BuildContext context) => Container(
    width: 20, height: 20,
    decoration: BoxDecoration(
      color: color, shape: BoxShape.circle,
      border: Border.all(color: Colors.white.withOpacity(0.60), width: 2.5),
      boxShadow: [BoxShadow(color: color.withOpacity(0.65), blurRadius: 8)]),
  );
}

class _ModeCard extends StatelessWidget {
  final String emoji, title, desc;
  final bool selected;
  final VoidCallback onTap;
  const _ModeCard({required this.emoji, required this.title, required this.desc,
    required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: selected ? AppColors.gold.withOpacity(0.13) : Colors.white.withOpacity(0.09),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: selected ? AppColors.gold : Colors.white.withOpacity(0.14),
          width: selected ? 2 : 1.5),
        boxShadow: selected ? [BoxShadow(color: AppColors.gold.withOpacity(0.25),
          blurRadius: 16)] : []),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(emoji, style: const TextStyle(fontSize: 28)),
        const SizedBox(height: 6),
        Text(title,
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800,
            color: selected ? AppColors.gold : Colors.white)),
        const SizedBox(height: 4),
        Text(desc, style: TextStyle(fontSize: 10,
          color: Colors.white.withOpacity(0.55)),
          textAlign: TextAlign.center),
      ]),
    ),
  );
}

class _ColorChipButton extends StatelessWidget {
  final PlayerColor color;
  final bool selected;
  final VoidCallback onTap;
  const _ColorChipButton({required this.color, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final col = ludoColor(color);
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        height: 40, alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected ? col : col.withOpacity(0.32),
          borderRadius: BorderRadius.circular(10),
          border: selected ? Border.all(color: Colors.white, width: 2) : null,
          boxShadow: selected ? [BoxShadow(color: Colors.black.withOpacity(0.40),
            blurRadius: 8)] : []),
        child: Text(colorLabel(color),
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white)),
      ),
    );
  }
}

class _GlowButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _GlowButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: double.infinity, height: 58,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Color(0xFFFFE57F), Color(0xFFFFD700),
                   Color(0xFFFFA000), Color(0xFFFF6F00)]),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [BoxShadow(color: Color(0x80FFA000), blurRadius: 24,
          offset: Offset(0, 6))]),
      child: Text(label,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900,
          letterSpacing: 2.5, color: Color(0xFF1A0500))),
    ),
  );
}
